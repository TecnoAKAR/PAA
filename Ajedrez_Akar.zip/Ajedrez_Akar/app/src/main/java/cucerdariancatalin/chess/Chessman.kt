package cucerdariancatalin.chess

enum class Chessman {
    KING,
    QUEEN,
    BISHOP,
    ROOK,
    KNIGHT,
    PAWN,
}