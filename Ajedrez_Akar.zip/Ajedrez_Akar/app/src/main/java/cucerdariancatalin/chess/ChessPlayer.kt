package cucerdariancatalin.chess

enum class ChessPlayer {
    WHITE,
    BLACK
}