package cucerdariancatalin.chess

class Square(val col: Int, val row:Int) {
}